#ifndef SERIALREADER_H
#define SERIALREADER_H

#include <QObject>
#include <QDebug>
#include <windows.h>
#include <QTimer>
#include <PCANBasic.h>
#include <QPushButton>

class SerialReader : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QString labelValue READ labelValue NOTIFY labelValueChanged)
    Q_PROPERTY(QString label1Value READ label1Value NOTIFY label1ValueChanged)
    Q_PROPERTY(QString label2Value READ label2Value NOTIFY label2ValueChanged)
    Q_PROPERTY(QString blowerStageValue READ blowerStageValue NOTIFY blowerStageChanged)
    Q_PROPERTY(bool autoActive READ autoActive NOTIFY autoActiveChanged)
    Q_PROPERTY(bool hvacActive READ hvacActive NOTIFY hvacActiveChanged)
    Q_PROPERTY(bool rearWindowResistanceActive READ rearWindowResistanceActive NOTIFY rearWindowResistanceActiveChanged)
    Q_PROPERTY(bool airFlowModeInside READ airFlowModeInside NOTIFY airFlowModeChanged)
    Q_PROPERTY(bool airFlowModeInside1 READ airFlowModeInside1 NOTIFY airFlowModeChanged)
    Q_PROPERTY(bool airFlowModeInside2 READ airFlowModeInside2 NOTIFY airFlowModeChanged)

public:
    explicit SerialReader(QObject *parent = nullptr);
    ~SerialReader();
    QString labelValue() const;
    QString label1Value() const;
    QString label2Value() const;
    QString blowerStageValue() const;
    bool autoActive() const;
    bool hvacActive() const;
    bool rearWindowResistanceActive() const;
    bool airFlowModeInside() const;
    bool airFlowModeInside1() const;
    bool airFlowModeInside2() const;

    QPushButton* createPlusButton();
    QPushButton* createMinusButton();
    QPushButton* createPlus1Button();
    QPushButton* createMinus1Button();
    QPushButton* createAutoActiveButton();
    QPushButton* createHvacActiveButton();
    QPushButton* createRearWindowResistanceButton();
    QPushButton* createAirFlowModeButton();
    QPushButton* createAirFlowMode1Button();
    QPushButton* createAirFlowMode2Button();

public slots:
    void readData();
    void setTemperature(int temperature);
    void increaseTemperature();
    void decreaseTemperature();
    void setBlowerStage(int stage);
    void increaseBlowerStage();
    void decreaseBlowerStage();
    void toggleAutoActive();
    void toggleHvacActive();
    void toggleRearWindowResistance();
    void toggleAirFlowMode();
    void toggleAirFlowMode1();
    void toggleAirFlowMode2();

signals:
    void labelValueChanged();
    void label1ValueChanged();
    void label2ValueChanged();
    void blowerStageChanged();
    void autoActiveChanged();
    void hvacActiveChanged();
    void rearWindowResistanceActiveChanged();
    void airFlowModeChanged();

private:
    void setLabelValue(const QString &value);
    void setLabel1Value(const QString &value);
    void setLabel2Value(const QString &value);
    void setBlowerStageValue(const QString &value);
    void sendTemperatureMessage(int temperature);
    void sendBlowerStageMessage(int stage);
    void setAutoActive(bool active);
    void sendAutoActiveMessage();
    void setHvacActive(bool active);
    void sendHvacActiveMessage();
    void setRearWindowResistanceActive(bool active);
    void sendRearWindowResistanceMessage();
    void setAirFlowModeInside(bool inside);
    void setAirFlowModeInside1(bool inside);
    void setAirFlowModeInside2(bool inside);
    void sendAirFlowModeMessage();

    QString m_labelValue;
    QString m_label1Value;
    QString m_label2Value;
    QString m_blowerStageValue;

    TPCANHandle m_handle;
    QTimer m_timer;

    int m_temperature;
    int m_blowerStage;
    bool m_autoActive;
    bool m_hvacActive;
    bool m_rearWindowResistanceActive;
    bool m_airFlowModeInside;
    bool m_airFlowModeInside1;
    bool m_airFlowModeInside2;
};

#endif // SERIALREADER_H
