#include "serialreader.h"
#include <QDebug>
#include <QTimer>

SerialReader::SerialReader(QObject *parent)
    : QObject(parent), m_handle(PCAN_USBBUS1), m_temperature(20), m_blowerStage(1), m_autoActive(false), m_hvacActive(false), m_rearWindowResistanceActive(false), m_airFlowModeInside(true), m_airFlowModeInside1(true), m_airFlowModeInside2(true)
{
    connect(&m_timer, &QTimer::timeout, this, &SerialReader::readData);
    TPCANStatus status = CAN_Initialize(m_handle, PCAN_BAUD_500K);
    if (status == PCAN_ERROR_OK) {
        qDebug() << "Connected to PCAN device.";
    }
    else
    {
        qDebug() << "notConnected to PCAN device.";
    }
    setTemperature(m_temperature);
    setBlowerStage(m_blowerStage);
    m_timer.start(100);
}

SerialReader::~SerialReader()
{

}

bool SerialReader::airFlowModeInside() const
{
    return m_airFlowModeInside;
}

bool SerialReader::airFlowModeInside1() const
{
    return m_airFlowModeInside1;
}

bool SerialReader::airFlowModeInside2() const
{
    return m_airFlowModeInside2;
}

void SerialReader::setAirFlowModeInside(bool inside)
{
    if (m_airFlowModeInside != inside){
        m_airFlowModeInside = inside;
        sendAirFlowModeMessage();
        emit airFlowModeChanged();
    }
}

void SerialReader::setAirFlowModeInside1(bool inside)
{
    if (m_airFlowModeInside1 != inside){
        m_airFlowModeInside1 = inside;
        sendAirFlowModeMessage();
        emit airFlowModeChanged();
    }
}

void SerialReader::setAirFlowModeInside2(bool inside)
{
    if(m_airFlowModeInside2 != inside){
        m_airFlowModeInside2 = inside;
        sendAirFlowModeMessage();
        emit airFlowModeChanged();
    }
}

void SerialReader::toggleAirFlowMode()
{
    setAirFlowModeInside(!m_airFlowModeInside);
}

void SerialReader::toggleAirFlowMode1()
{
    setAirFlowModeInside1(!m_airFlowModeInside1);
}

void SerialReader::toggleAirFlowMode2()
{
    setAirFlowModeInside2(!m_airFlowModeInside2);
}

QPushButton* SerialReader::createAirFlowModeButton()
{
    QPushButton* button = new QPushButton("Air Flow");
    button->setCheckable(true);
    connect(button, &QPushButton::clicked, this, &SerialReader::toggleAirFlowMode);
    return button;
}

QPushButton* SerialReader::createAirFlowMode1Button()
{
    QPushButton* button = new QPushButton("Air Flow 1");
    button->setCheckable(true);
    connect(button, &QPushButton::clicked, this, &SerialReader::toggleAirFlowMode1);
    return button;
}

QPushButton* SerialReader::createAirFlowMode2Button()
{
    QPushButton* button = new QPushButton("Air Flow 2");
    button->setCheckable(true);
    connect(button, &QPushButton::clicked, this, &SerialReader::toggleAirFlowMode2);
    return button;
}

void SerialReader::sendAirFlowModeMessage()
{
    TPCANMsg message;
    message.ID = 0x400;
    message.LEN = 8;
    message.MSGTYPE = PCAN_MESSAGE_STANDARD;

    if (CAN_Read(m_handle, &message, nullptr) != PCAN_ERROR_OK){
        for (int i = 0; i < 8; i++){
            message.DATA[i] = 0;
        }
    }

    uint16_t airFlowMode = 0;
    if (m_airFlowModeInside) airFlowMode |= 0x0001;
    if (m_airFlowModeInside1) airFlowMode |= 0x0002;
    if (m_airFlowModeInside2) airFlowMode |= 0x0004;

    if (m_hvacActive) {
        message.DATA[0] |= 0x01;
    }
    if (m_autoActive) {
        message.DATA[0] |= 0x02;
    }
    message.DATA[3] = (message.DATA[3] & 0xF8) | (m_blowerStage & 0x07);
    if (m_rearWindowResistanceActive) {
        message.DATA[3] |= 0x08;
    }

    TPCANStatus status = CAN_Write(m_handle, &message);
    if (status != PCAN_ERROR_OK)
    {
        qDebug() << "Failed to send Air Flow Mode message. Error code:" << status;
    }
    else
    {
        qDebug() << "Air Flow Mode message sent successfully. Inside:" << m_airFlowModeInside;
    }
}

bool SerialReader::rearWindowResistanceActive() const
{
    return m_rearWindowResistanceActive;
}

void SerialReader::setRearWindowResistanceActive(bool active)
{
    if (m_rearWindowResistanceActive != active){
        m_rearWindowResistanceActive = active;
        sendRearWindowResistanceMessage();
        emit rearWindowResistanceActiveChanged();
    }
}

void SerialReader::toggleRearWindowResistance()
{
    setRearWindowResistanceActive(!m_rearWindowResistanceActive);
}

QPushButton* SerialReader::createRearWindowResistanceButton()
{
    QPushButton* button = new QPushButton("Rear Window");
    button->setCheckable(true);
    connect(button, &QPushButton::clicked, this, &SerialReader::toggleRearWindowResistance);
    return button;
}

void SerialReader::sendRearWindowResistanceMessage()
{
    TPCANMsg message;
    message.ID = 0x400;
    message.LEN = 8;
    message.MSGTYPE = PCAN_MESSAGE_STANDARD;

    if(CAN_Read(m_handle, &message, nullptr) != PCAN_ERROR_OK)
    {
        for (int i = 0; i < 8; i++){
            message.DATA[i] = 0;
        }
    }

    if(m_rearWindowResistanceActive){
        message.DATA[3] |= 0x08;
    } else {
        message.DATA[3] &= 0xF7;
    }
    if (m_hvacActive) {
        message.DATA[0] |= 0x01;
    }
    if (m_autoActive) {
        message.DATA[0] |= 0x02;
    }
    message.DATA[3] = (message.DATA[3] & 0xF8) | (m_blowerStage & 0x07);

    TPCANStatus status = CAN_Write(m_handle, &message);
    if (status != PCAN_ERROR_OK)
    {
        qDebug() << "Failed to send Rear Window Resistance message. Error code:" << status;
    }
    else
    {
        qDebug() << "Rear Window Resistance message sent successfully. State:" << m_rearWindowResistanceActive;
    }

}

bool SerialReader::hvacActive() const
{
    return m_hvacActive;
}

void SerialReader::setHvacActive(bool active)
{
    if (m_hvacActive != active) {
        m_hvacActive = active;
        sendHvacActiveMessage();
        emit hvacActiveChanged();
    }
}

void SerialReader::toggleHvacActive()
{
    setHvacActive(!m_hvacActive);
}

QPushButton* SerialReader::createHvacActiveButton()
{
    QPushButton* button = new QPushButton("HVAC");
    button->setCheckable(true);
    connect(button, &QPushButton::clicked, this, &SerialReader::toggleHvacActive);
    return button;
}

void SerialReader::sendHvacActiveMessage()
{
    TPCANMsg message;
    message.ID = 0x400;
    message.LEN = 8;
    message.MSGTYPE = PCAN_MESSAGE_STANDARD;


    if (CAN_Read(m_handle, &message, nullptr) != PCAN_ERROR_OK) {

        for (int i = 0; i < 8; i++) {
            message.DATA[i] = 0;
        }
    }


    if (m_hvacActive) {
        message.DATA[0] |= 0x01;
    } else {
        message.DATA[0] &= 0xFE;
    }


    if (m_autoActive) {
        message.DATA[0] |= 0x02;
    } else {
        message.DATA[0] &= 0xFD;
    }

    message.DATA[3] = static_cast<BYTE>(m_blowerStage);

    TPCANStatus status = CAN_Write(m_handle, &message);
    if (status != PCAN_ERROR_OK)
    {
        qDebug() << "Failed to send HVAC Active message. Error code:" << status;
    }
    else
    {
        qDebug() << "HVAC Active message sent successfully. State:" << m_hvacActive;
    }
}

bool SerialReader::autoActive() const
{
    return m_autoActive;
}

void SerialReader::setAutoActive(bool active)
{
    if (m_autoActive != active) {
        m_autoActive = active;
        sendAutoActiveMessage();
        emit autoActiveChanged();
    }
}

void SerialReader::toggleAutoActive()
{
    setAutoActive(!m_autoActive);
}

QPushButton* SerialReader::createAutoActiveButton()
{
    QPushButton* button = new QPushButton("Auto");
    button->setCheckable(true);
    connect(button, &QPushButton::clicked, this, &SerialReader::toggleAutoActive);
    return button;
}

void SerialReader::sendAutoActiveMessage()
{
    TPCANMsg message;
    message.ID = 0x400;
    message.LEN = 8;
    message.MSGTYPE = PCAN_MESSAGE_STANDARD;


    if (CAN_Read(m_handle, &message, nullptr) != PCAN_ERROR_OK) {

        for (int i = 0; i < 8; i++) {
            message.DATA[i] = 0;
        }
    }


    if (m_autoActive) {
        message.DATA[0] |= 0x01;
    } else {
        message.DATA[0] &= 0xFE;
    }

    message.DATA[3] = static_cast<BYTE>(m_blowerStage);

    TPCANStatus status = CAN_Write(m_handle, &message);
    if (status != PCAN_ERROR_OK)
    {
        qDebug() << "Failed to send Auto Active message. Error code:" << status;
    }
    else
    {
        qDebug() << "Auto Active message sent successfully. State:" << m_autoActive;
    }
}

QString SerialReader::blowerStageValue() const
{
    return m_blowerStageValue;
}

QString SerialReader::labelValue() const
{
    return m_labelValue;
}

QString SerialReader::label1Value() const
{
    return m_label1Value;
}

QString SerialReader::label2Value() const
{
    return m_label2Value;
}

void SerialReader::setLabelValue(const QString &value)
{
    if (m_labelValue != value){
        m_labelValue = value;
        emit labelValueChanged();
    }
}

void SerialReader::setLabel1Value(const QString &value)
{
    if (m_label1Value != value){
        m_label1Value = value;
        emit label1ValueChanged();
    }
}

void SerialReader::setLabel2Value(const QString &value)
{
    if (m_label2Value != value){
        m_label2Value = value;
        emit label2ValueChanged();
    }
}

void SerialReader::setBlowerStageValue(const QString &value)
{
    if (m_blowerStageValue != value) {
        m_blowerStageValue = value;
        emit blowerStageChanged();
    }
}

void SerialReader::setBlowerStage(int stage)
{
    if (stage >= 1 && stage <= 3) {
        m_blowerStage = stage;
        setBlowerStageValue(QString::number(stage));
        sendBlowerStageMessage(stage);
        emit blowerStageChanged();
    }
}

void SerialReader::increaseBlowerStage()
{
    if (m_blowerStage < 3) {
        setBlowerStage(m_blowerStage + 1);
    }
}

void SerialReader::decreaseBlowerStage()
{
    if (m_blowerStage > 1) {
        setBlowerStage(m_blowerStage - 1);
    }
}

void SerialReader::sendBlowerStageMessage(int stage)
{
    TPCANMsg message;
    message.ID = 0x400;
    message.LEN = 8;
    message.MSGTYPE = PCAN_MESSAGE_STANDARD;


    if (CAN_Read(m_handle, &message, nullptr) != PCAN_ERROR_OK) {

        for (int i = 0; i < 8; i++) {
            message.DATA[i] = 0;
        }
    }


    message.DATA[3] = static_cast<BYTE>(stage);


    if (m_autoActive) {
        message.DATA[0] |= 0x01;
    } else {
        message.DATA[0] &= 0xFE;
    }

    TPCANStatus status = CAN_Write(m_handle, &message);
    if (status != PCAN_ERROR_OK)
    {
        qDebug() << "Failed to send Blower Stage message. Error code:" << status;
    }
    else
    {
        qDebug() << "Blower Stage message sent successfully. Stage:" << stage;
    }
}

void SerialReader::readData()
{
    TPCANMsg message;
    if (CAN_Read(m_handle, &message, nullptr) == PCAN_ERROR_OK) {
        if (message.ID == 0x104)
        {
            int temperature = message.DATA[5];
            setLabelValue(QString::number(temperature) + "°C");
            qDebug() << message.ID << "Data received. Temperature:" << temperature;
        }
        else if (message.ID == 0x104)
        {
            qDebug() << message.ID << "Data received. Temperature:" << message.DATA[1];
        }
    }
}

void SerialReader::setTemperature(int temperature)
{
    if (temperature >= 15 && temperature <= 35)
    {
        m_temperature = temperature;
        setLabelValue(QString::number(temperature) + "°C");
        sendTemperatureMessage(temperature);
        emit labelValueChanged();
    }
    else
    {
        qDebug() << "Invalid temperature value. Must be between 15 and 35.";
    }
}

void SerialReader::sendTemperatureMessage(int temperature)
{
    TPCANMsg message;
    message.ID = 0x400;
    message.LEN = 8;
    message.MSGTYPE = PCAN_MESSAGE_STANDARD;
    for (int i = 0; i < 8; i++) {
        message.DATA[i] = 0;
    }

    message.DATA[5] = static_cast<BYTE>(temperature);


    TPCANStatus status = CAN_Write(m_handle, &message);

    if (status != PCAN_ERROR_OK)
    {
        qDebug() << "Failed to send temperature message. Error code:" << status;
    }
    else
    {
        qDebug() << "Temperature message sent successfully. Temperature:" << temperature;
    }
}

QPushButton* SerialReader::createPlusButton()
{
    QPushButton* button = new QPushButton("+");
    connect(button, &QPushButton::clicked, this, &SerialReader::increaseTemperature);
    return button;
}

QPushButton* SerialReader::createMinusButton()
{
    QPushButton* button = new QPushButton("-");
    connect(button, &QPushButton::clicked, this, &SerialReader::decreaseTemperature);
    return button;
}

QPushButton* SerialReader::createPlus1Button()
{
    QPushButton* button = new QPushButton("+");
    connect(button, &QPushButton::clicked, this, &SerialReader::increaseBlowerStage);
    return button;
}

QPushButton* SerialReader::createMinus1Button()
{
    QPushButton* button = new QPushButton("-");
    connect(button, &QPushButton::clicked, this, &SerialReader::decreaseBlowerStage);
    return button;
}

void SerialReader::increaseTemperature()
{
    if (m_temperature < 35) {
        m_temperature++;
        setTemperature(m_temperature);
        qDebug() << "Temperature message sent successfully. Temperature:" << m_temperature;
    }
}

void SerialReader::decreaseTemperature()
{
    if (m_temperature > 15) {
        m_temperature--;
        setTemperature(m_temperature);
        qDebug() << "Temperature message sent successfully. Temperature:" << m_temperature;
    }
}
